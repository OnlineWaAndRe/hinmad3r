import torch
import torch.nn.functional as F

# 创建两个示例矩阵
matrix1 = torch.randn(3, 4)  # 例如，形状为 3*4 的矩阵
matrix2 = torch.randn(3, 4)  # 例如，形状为 3*4 的矩阵

# 对矩阵的每一行进行归一化
matrix1_normalized = F.normalize(matrix1, p=2, dim=1)
# matrix2_normalized = F.normalize(matrix2, p=2, dim=1)

# 计算余弦相似度
cosine_similarities = F.cosine_similarity(matrix1_normalized, matrix1_normalized, dim=1)

print(cosine_similarities)
