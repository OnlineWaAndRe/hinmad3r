import torch
import sys
import time
import wandb
import gc
import warnings
import numpy as np
import torch.nn.functional as F
from utils.tools import set_random_seed, get_efeat, plt_show, print_args, print_to_file
from utils.cluster import cluster
from utils.vision import draw
from utils.load_dataset import load_dataset
from utils.params import set_params
from utils.pytorchtools import EarlyStopping
from model.model import hinworld
warnings.filterwarnings('ignore')
import setproctitle
setproctitle.setproctitle("hinworld")

def computer_sim(x):
    x = x / torch.norm(x, dim = -1, keepdim=True)
    sim = torch.mm(x, x.T)
    return torch.sum(sim)

args = set_params()
path = sys.path[0] + "/data"
args.root = path
home_g, init_labels, num_classes, node_classes,dl, \
features_list, train_nid, val_nid, test_nid, adjm = load_dataset(args)

fet = torch.ones(26128,26128)
at = torch.FloatTensor(adjm.toarray())
count = torch.count_nonzero(at, dim = 1)
print(at)
print()
print(type(at))
print(type(fet))
a = fet * at

print(fet*at)
sys.exit()
fet = torch.mm(fet, fet.T)
a = adjm.dot(fet)
print(a.shape)
idx = [1,2,3,4]
t = a[idx]
print(t)
print(t.shape)
print(type(a))
# print(adjm[1].count_nonzero())

