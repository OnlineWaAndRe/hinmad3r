import torch
import torch.nn.functional as F

import numpy as np
from sklearn.metrics import pairwise_distances

x = torch.randn(5, 5)

x_drop = F.dropout(x, 0.5)
print(x_drop)
