import torch
import sys
import time
import wandb
import gc
import warnings
import numpy as np
import torch.nn.functional as F
from utils.tools import set_random_seed, get_efeat, plt_show, print_args, print_to_file
from utils.cluster import cluster
from utils.vision import draw
from utils.load_dataset import load_dataset
from utils.params import set_params
from utils.pytorchtools import EarlyStopping
from model.model import hinworld
warnings.filterwarnings('ignore')
import setproctitle
setproctitle.setproctitle("hinworld")

def computer_sim(x, mask, idx):
    x = F.normalize(x, p = 2, dim = -1)
    x = torch.matmul(x,x.T)
    x = 1 - x
    
    d = x.cpu() * mask
    d = d[idx]
    di = torch.sum(d, dim = 1)
    non = torch.count_nonzero(d, dim = 1).float()
    d_tgt = di / non
    return d_tgt

def mad(x, mask, idx):
    mask = torch.FloatTensor(mask.toarray())
    d_tgt = computer_sim(x, mask, idx)
    non = torch.count_nonzero(d_tgt)
    sum = torch.sum(d_tgt)
    mad = torch.div(sum, non)
    return mad

def mad_gap(x, mask, idx):
    mask_rmt = mask.dot(mask)
    mask_rmt = mask_rmt.dot(mask_rmt)
    mask_rmt = mask_rmt.dot(mask)
    
    mask = torch.FloatTensor(mask.toarray())
    mask_rmt = torch.FloatTensor(mask_rmt.toarray())
    
    mad_rmt = computer_sim(x, mask_rmt, idx)
    mad_nei = computer_sim(x, mask, idx)
    
    mad_rmt_mean = torch.mean(mad_rmt)
    
    mad_nei_mean = torch.mean(mad_nei)
    print("mad_rmt", mad_rmt_mean)
    print("mad_nei_mean", mad_nei_mean)
    mad_gap = mad_rmt_mean - mad_nei_mean

    return mad_gap

def draw_pic(emd, args, dl, p_labels, t_labesl, test_nid, num_classes, fp):
    # emd = net.get_emd(features_list, e_feat, node_type, test_nid)
    nmi, ari, label = cluster(args.c_num, emd, p_labels.cpu().numpy(), num_classes, fp = fp)
    draw(emd.cpu().detach().numpy(), t_labesl[test_nid].cpu().numpy(), nmi, args.dataset)
    return 

def run(args, fp):
    seeds = args.seeds
    # seeds = list(range(0,1000))
    len_seeds = len(seeds)
    micro_f1s = torch.zeros(len_seeds)
    macro_f1s = torch.zeros(len_seeds)
    nmis = torch.zeros(len_seeds)
    aris = torch.zeros(len_seeds)
    total_time = torch.zeros(len(seeds))
    len_seeds = 1
    for rep in range(len_seeds):
        set_random_seed(seeds[rep])
        path = sys.path[0] + "/data"
        args.root = path
        start_time = time.time()
        home_g, init_labels, num_classes, node_classes,dl, \
        features_list, train_nid, val_nid, test_nid, adjm = load_dataset(args)

        sttime = time.time()
        
        node_cnt = [feat.shape[0] for feat in features_list]
        e_feat = get_efeat(home_g, dl)

        in_dims = [features.shape[1] for features in features_list]
        num_etypes = len(dl.links['count']) * 2 + 1
        heads = [args.num_heads] * args.num_layers + [1]
        node_type = [i for i, z in zip(range(len(node_cnt)), node_cnt) for x in range(z)]
        node_type = torch.tensor(node_type)

        if torch.cuda.is_available():
            device = torch.device("cuda:" + str(args.gpu))
            torch.cuda.set_device(args.gpu)
            home_g = home_g.to(device)
            e_feat = e_feat.to(device)
            init_labels = init_labels.to(device)
            node_type = node_type.to(device)
            features_list = [feat.to(device) for feat in features_list]
        else : device = torch.device("cpu")
        
        net = hinworld(home_g=home_g, in_dims=in_dims, edge_feats=args.e_feats, num_etypes=num_etypes,
            in_feats=args.n_feats, num_type=node_classes, type_feats=args.t_feats, 
            num_layers=args.num_layers, nclass=num_classes, heads=heads, feat_drop=args.feat_drop,
            attn_drop = args.attn_drop, alpha = args.alpha, leaky_relu_rate=args.leaky_relu_rate,
            msg_drop=args.msg_drop, residual=args.residual)
        net.to(device)
        optimizer = torch.optim.Adam(net.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min')
        save_path=sys.path[0] + '/outputs/checkpoint/hw_{}.pt'.format(args.dataset)
        early_stopping = EarlyStopping(patience=args.patience, verbose=True, save_path = save_path)
        
        plt_lrs = []
        plt_train_loss = []
        plt_val_loss = []
        plt_maf1 = []
        plt_m1f1 = []
        
        for epoch in range(args.epochs):
            plt_lrs.append(optimizer.param_groups[0]['lr'])
            t_start = time.time()
            net.train()
            logits,_ = net(features_list, e_feat, node_type, train_nid)
            logp = F.log_softmax(logits, 1)
            train_loss = F.nll_loss(logp, init_labels[train_nid])
            
            plt_train_loss.append(train_loss.item())
            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()
            t_end = time.time()
            print('Epoch {:05d} | Train_Loss: {:.4f} | Time: {:.4f}'.format(
                    epoch, train_loss.item(), t_end-t_start))
            
            # if(epoch == 0 or epoch == 50 or epoch == 100 or epoch == 200):
            #     draw_pic(logits, args, dl,init_labels, train_nid, num_classes, fp)
        
            #val
            t_start = time.time()
            net.eval()
            with torch.no_grad():
                logits,_ = net(features_list, e_feat, node_type, val_nid)
                logp = F.log_softmax(logits, 1)
                val_loss = F.nll_loss(logp, init_labels[val_nid])
                plt_val_loss.append(val_loss.item())
                pred = logits.cpu().numpy().argmax(axis=1)
                onehot = np.eye(num_classes, dtype=np.int32)
                pred = onehot[pred]
                vret = dl.evaluate_valid(pred, dl.labels_train['data'][val_nid])
                print(vret)
                plt_m1f1.append(vret["micro-f1"])
                plt_maf1.append(vret["macro-f1"])
                if(epoch == 50 or epoch == 100 or epoch == 200 or epoch == 400 or epoch == 450):
                    draw_pic(logits, args, dl, logp,  init_labels, val_nid, num_classes, fp)
            # scheduler.step(val_loss)
            t_end = time.time()
            print('Epoch {:05d} | Val_Loss {:.4f} | Time(s) {:.4f}'.format(
                    epoch, val_loss.item(), t_end - t_start))
            # wandb.log({"micro-f1":vret["micro-f1"], "macro-f1": vret["macro-f1"], "val_loss": val_loss})
            early_stopping(val_loss,net)
            if early_stopping.early_stop:
                print('Early stopping!')
                break
        draw_pic(logits, args, dl, init_labels, val_nid, num_classes, fp)
        #test
        net.load_state_dict(torch.load(save_path))
        net.eval()
        with torch.no_grad():
            logits, emds = net(features_list, e_feat, node_type, test_nid)
            test_logits = logits
            pred = test_logits.cpu().numpy().argmax(axis=1)
            onehot = np.eye(num_classes, dtype=np.int32)
            pred = onehot[pred]
            result = dl.evaluate_valid(pred, dl.labels_test['data'][test_nid])
            end_time = time.time()
            edtime = time.time()
            # dl.gen_file_for_evaluate(test_idx=test_nid, label=pred, file_name=f"./outputs/{args.dataset}/{args.dataset}_{rep}.txt")
            micro_f1s[rep] = result['micro-f1']
            macro_f1s[rep] = result['macro-f1']
            total_time[rep] = edtime - sttime
        print("total compuate times ->", end_time - start_time)
        print(result)
        print("seed = {}".format(seeds[rep]), file=fp)
        print(result, file=fp)
        

        # plt_show(plt_lrs, type="lrs")
        # plt_show(plt_train_loss, type="train_loss")
        # plt_show(plt_val_loss, type = "val_loss")
        # plt_show(plt_m1f1, type = "m1f1")
        # plt_show(plt_maf1, type="maf1")
        
        
        # emd = net.get_emd(features_list, e_feat, node_type, test_nid)
        # nmi, ari = cluster(args.c_num, emd, dl.labels_test['data'][test_nid], num_classes,fp = fp)
        # draw(emd.cpu().detach().numpy(), init_labels[test_nid].cpu().numpy(), nmi, args.dataset)
        
        # nmis[rep] = nmi
        # aris[rep] = ari
    mamdict = {'name1':'Macro-f1', 'name2':'Micro-f1', 'val1': macro_f1s, 'val2': micro_f1s}
    nmardict = {'name1':'nmis', 'name2':'aris', 'val1': nmis, 'val2': aris}
    print_to_file(mamdict, fp)
    print_args(args, fp)
    # sim = mad_gap(emds, adjm, train_nid)
    # print("sim = ",sim)
    # print("sim = {}".format(sim), file=fp)
    # num_params = sum(p.numel() for p in net.parameters())
    # print(num_params / 1e6)
    # print(num_params / 1e6, file=fp)
    print("spend time = {}".format(total_time.mean()), file = fp)
    print("", file=fp)
    
    # wandb.finish()
if __name__ == "__main__":
    args = set_params()
    # wandb.init(
    #     project="hinworld",
    #     config={
    #         "learning_rate":args.lr,
    #         "dataset":args.dataset,
    #     }
    # )
    f_name = args.dataset + "/" + args.dataset + ".txt"
    fp = open(r"./outputs/" + f_name, 'a+')
    fts = np.arange(0, 0.1, 0.001)
    # for ft in fts:
    #     args.alpha = ft
    #     run(args, fp)
    # args.t_feats = 256
    # args.alpha = 0.4
    run(args, fp)
    fp.close()