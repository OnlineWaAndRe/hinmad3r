import argparse
import sys

argv = sys.argv
dataname = argv[1]
def ACM_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('--seeds', type=int, default= [70,70,70,70,70])
    parser.add_argument("--root", type=str, default="../data")
    parser.add_argument('--dataset', type=str, default="ACM")
    parser.add_argument('--ACM_keep_F', type=bool, default=True)
    parser.add_argument('--epochs', type=int, default=2023)
    parser.add_argument('--patience', type=int, default=50)
    parser.add_argument('--lr', type=float, default=2e-4)
    parser.add_argument('--weight_decay', type=float, default=2e-5)
    parser.add_argument('--msg_drop', type=float, default=0.35000000000000003)
    parser.add_argument('--num_heads', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--e_feats', type=int, default=128)
    parser.add_argument('--n_feats', type=int, default=64)
    parser.add_argument('--t_feats', type=int, default=32)
    parser.add_argument('--feat_drop', type=float, default=0.5)
    # parser.add_argument('--attn_drop', type=float, default=0.08)
    parser.add_argument('--attn_drop', type=float, default=0)
    
    parser.add_argument('--alpha', type=float, default=0.19)
    parser.add_argument('--leaky_relu_rate', type=float, default=0)
    parser.add_argument('--c_num', type=int, default=10)
    args, _ = parser.parse_known_args()
    return args

def DBLP_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, default=1)
    parser.add_argument('--seeds', type=int, default= [0,0,0,0,1])
    parser.add_argument("--root", type=str, default="../data")
    parser.add_argument('--dataset', type=str, default="DBLP")
    parser.add_argument('--epochs', type=int, default=2023)
    parser.add_argument('--patience', type=int, default=50)
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--weight_decay', type=float, default=2e-6)
    parser.add_argument('--num_heads', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--e_feats', type=int, default=512)
    parser.add_argument('--n_feats', type=int, default=128)
    parser.add_argument('--t_feats', type=int, default=32)
    parser.add_argument('--feat_drop', type=float, default=0.41000000000000003)
    parser.add_argument('--attn_drop', type=float, default=0)
    parser.add_argument('--alpha', type=float, default=0)
    parser.add_argument('--msg_drop', type=float, default=0.3)
    parser.add_argument('--leaky_relu_rate', type=float, default=0)
    parser.add_argument('--c_num', type=int, default=10)
    args, _ = parser.parse_known_args()
    return args

def Freebase_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, default=1)
    parser.add_argument('--seeds', type=int, default= [47,47,47,47,10])
    parser.add_argument("--root", type=str, default="../data")
    parser.add_argument('--dataset', type=str, default="Freebase")
    parser.add_argument('--epochs', type=int, default=2023)
    parser.add_argument('--patience', type=int, default=50)
    parser.add_argument('--lr', type=float, default=2e-4)
    parser.add_argument('--weight_decay', type=float, default=1e-5)
    parser.add_argument('--num_heads', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=3)
    parser.add_argument('--e_feats', type=int, default=128)
    parser.add_argument('--n_feats', type=int, default=64)
    parser.add_argument('--t_feats', type=int, default=32)
    parser.add_argument('--msg_drop', type=float, default=0)
    parser.add_argument('--feat_drop', type=float, default=0.5)
    parser.add_argument('--attn_drop', type=float, default=0.34)
    parser.add_argument('--alpha', type=float, default=0)
    parser.add_argument('--leaky_relu_rate', type=float, default=0.06)
    parser.add_argument('--c_num', type=int, default=10)
    args, _ = parser.parse_known_args()
    return args

def IMDB_params():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('--seeds', type=int, default= [1819,1819,1819,1819,40])
    parser.add_argument("--root", type=str, default="../data")
    parser.add_argument('--dataset', type=str, default="IMDB")
    parser.add_argument('--epochs', type=int, default=2023)
    parser.add_argument('--patience', type=int, default=50)
    parser.add_argument('--lr', type=float, default=8e-4)
    parser.add_argument('--weight_decay', type=float, default=5e-5)
    parser.add_argument('--num_heads', type=int, default=1)
    parser.add_argument('--num_layers', type=int, default=2)
    parser.add_argument('--e_feats', type=int, default=128)
    parser.add_argument('--n_feats', type=int, default=128)
    parser.add_argument('--t_feats', type=int, default=64)
    parser.add_argument('--msg_drop', type=float, default=0.49)
    parser.add_argument('--feat_drop', type=float, default=0.49)
    parser.add_argument('--attn_drop', type=float, default=0) 
    parser.add_argument('--alpha', type=float, default=0.03)
    parser.add_argument('--leaky_relu_rate', type=float, default=0.08)
    parser.add_argument('--c_num', type=int, default=10)
    args, _ = parser.parse_known_args()
    return args
def set_params():
    if dataname == "ACM":
        return ACM_params()
    elif dataname == "DBLP":
        return DBLP_params()
    elif dataname == "Freebase":
        return Freebase_params()
    elif dataname == "IMDB":
        return IMDB_params()