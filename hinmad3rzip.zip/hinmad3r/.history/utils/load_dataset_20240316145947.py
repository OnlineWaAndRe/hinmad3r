import torch
import numpy as np
import networkx as nx
from torch_sparse import SparseTensor
import dgl
import sys
from utils.data_loader import data_loader
def load_dataset(args):
    dl = data_loader(f'{args.root}/{args.dataset}')
    # use one-hot index vectors for nods with no attributes
    # === feats ===
    features_list = []
    for i in range(len(dl.nodes['count'])):
        th = dl.nodes['attr'][i]
        if th is None:
            features_list.append(torch.eye(dl.nodes['count'][i]))
        else:
            features_list.append(torch.FloatTensor(th))
    adjM = sum(dl.links['data'].values()) 
    
    # === labels ===
    node_classes = len(dl.nodes['count'].keys())
    num_classes = dl.labels_train['num_classes']
    init_labels = np.zeros((dl.nodes['count'][0], num_classes), dtype=int)

    val_ratio = 0.2
    train_nid = np.nonzero(dl.labels_train['mask'])[0]
    np.random.shuffle(train_nid)
    split = int(train_nid.shape[0]*val_ratio)
    val_nid = train_nid[:split]
    train_nid = train_nid[split:]
    train_nid = np.sort(train_nid)
    val_nid = np.sort(val_nid)
    test_nid = np.nonzero(dl.labels_test['mask'])[0]

    init_labels[train_nid] = dl.labels_train['data'][train_nid]
    init_labels[val_nid] = dl.labels_train['data'][val_nid]
    init_labels[test_nid] = dl.labels_test['data'][test_nid]
    
    if args.dataset != 'IMDB':
        init_labels = init_labels.argmax(axis=1)
        init_labels = torch.LongTensor(init_labels)
    elif args.dataset == "IMDB":
        init_labels = torch.FloatTensor(init_labels)
    train_val_test_idx = {}
    train_val_test_idx['train_idx'] = train_nid
    train_val_test_idx['val_idx'] = val_nid
    train_val_test_idx['test_idx'] = test_nid
    
    home_g = dgl.DGLGraph(adjM + (adjM.T))

    home_g = dgl.remove_self_loop(home_g)
    home_g = dgl.add_self_loop(home_g)
    return home_g, init_labels, num_classes, node_classes, dl, \
        features_list, train_nid, val_nid, test_nid\
            
