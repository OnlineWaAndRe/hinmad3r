import numpy as np
import datetime
import sys
from sklearn.manifold import TSNE
# For the UCI ML handwritten digits dataset
from sklearn.datasets import load_digits

# Import matplotlib for plotting graphs ans seaborn for attractive graphics.
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import seaborn as sns

def plot(x, colors, nmi, dataname):
    # Choosing color palette
    # https://seaborn.pydata.org/generated/seaborn.color_palette.html
    palette = np.array(sns.color_palette("pastel", 10))
    # pastel, husl, and so on
    f = plt.figure(figsize=(8, 8))
    ax = plt.axes()
    ax.patch.set_alpha(0)
    class_labels = colors
    unique_labels = np.unique(class_labels)
    unique_colors = np.linspace(0, 1, len(unique_labels))
    label_to_color = {label: color for label, color in zip(unique_labels, unique_colors)}

    labels_as_tuples = [tuple(label) for label in class_labels]


    colors = [label_to_color[label_tuple] for label_tuple in labels_as_tuples]



    handles = [plt.Line2D([0], [0], marker='o', color='w', markerfacecolor=palette[color_map[i].astype(np.int8)], markersize=10, label=label) for i, label in enumerate(unique_labels)]
    plt.legend(handles=handles, title='Class Labels')
    
    plt.scatter(x[:,0], x[:,1], lw=0, s=40, c=palette[colors.astype(np.int8)])
    # ax.axis('off') # 关闭坐标轴显示
    time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    plt.savefig('./pic/'+dataname+'/' + str(time) + '-' + str(nmi)[:5] + '.png', dpi=120,transparent=False)
    # return f, ax, txts

def draw(embds,label,nmi, dataname):
    digits_final = TSNE(perplexity=30).fit_transform(embds)
    plot(digits_final, label, nmi, dataname)