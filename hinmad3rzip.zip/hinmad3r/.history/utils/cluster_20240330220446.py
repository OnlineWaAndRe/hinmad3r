import numpy as np
import torch
import sys
from sklearn.cluster import KMeans
from sklearn.metrics.cluster import normalized_mutual_info_score, adjusted_rand_score

def evaluate_cluster(embeds, y, n_labels, kmeans_random_state):
    Y_pred = KMeans(n_labels, random_state=kmeans_random_state).fit(embeds).predict(embeds)
    nmi = normalized_mutual_info_score(y, Y_pred)
    ari = adjusted_rand_score(y, Y_pred)
    return nmi, ari

def cluster(c_num, embeds, label, nclass, fp):
    nmi_list, ari_list = [], []
    label = label.argmax(axis=1)
    embeds = embeds.cpu().data.numpy()
    for i in range(c_num):
        nmi, ari = evaluate_cluster(embeds, label, nclass, i)
        nmi_list.append(nmi)
        ari_list.append(ari)
    print({'nmi':np.mean(nmi_list), 'ari': np.mean(ari_list)})
    print({'nmi':np.mean(nmi_list), 'ari': np.mean(ari_list)}, file=fp)
    return np.mean(nmi_list), np.mean(ari)