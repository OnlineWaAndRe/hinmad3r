import random
import numpy as np
import torch
import matplotlib.pyplot as plt

def set_random_seed(seed=0):
    # random.seed(seed)
    # np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.enabled = False
        torch.backends.cudnn.benchmark = False

def get_efeat(g, dl):
    edge2type = {}
    for k in dl.links['data']:
        for u,v in zip(*dl.links['data'][k].nonzero()):
            edge2type[(u,v)] = k
    for i in range(dl.nodes['total']):
        if (i,i) not in edge2type:
            edge2type[(i,i)] = len(dl.links['count'])
    for k in dl.links['data']:
        for u,v in zip(*dl.links['data'][k].nonzero()):
            if (v,u) not in edge2type:
                edge2type[(v,u)] = k+1+len(dl.links['count'])
    
    e_feat = []
    for u, v in zip(*g.edges()):
        u = u.cpu().item()
        v = v.cpu().item()
        e_feat.append(edge2type[(u,v)])
        
    e_feat = torch.tensor(e_feat, dtype=torch.long)
    return e_feat

def nei_agg(dataset):
    if dataset == 'DBLP':
        tgt_type = 'A'
        node_types = ['A', 'P', 'T', 'V']
        extra_metapath = []
    elif dataset == 'ACM':
        tgt_type = 'P'
        node_types = ['P', 'A', 'S']
        extra_metapath = []
    elif dataset == 'IMDB':
        tgt_type = 'M'
        node_types = ['M', 'A', 'D', 'K']
        extra_metapath = []
    elif dataset == 'Freebase':
        tgt_type = 'M'
        node_types = ['M', 'A', 'D', 'W']
        extra_metapath = []
    elif dataset == 'AMiner':
        tgt_type = 'P'
        node_types = ['P', 'A', 'R']
        extra_metapath = []
    else:
        assert 0
    return tgt_type, node_types, extra_metapath


def plt_show(y , type = "lrs"):
    plt.figure()
    x = list(range(len(y)))
    plt.plot(x, y)
    plt.xlabel("epochs")
    plt.ylabel(type)
    plt.show()
    plt.savefig(type+".png")

def print_args(args,fp):
    s = str(vars(args))
    parts = s.split(",")
    out = '\n'.join(','.join(parts[i:i+5]) for i in range(0, len(parts), 5))
    print(out, file=fp)
    

def sp_to_spt(mat):
    coo = mat.tocoo()
    values = coo.data
    indices = np.vstack((coo.row, coo.col))

    i = torch.LongTensor(indices)
    v = torch.FloatTensor(values)
    shape = coo.shape

    return torch.sparse.FloatTensor(i, v, torch.Size(shape))

def mat2tensor(mat):
    if type(mat) is np.ndarray:
        return torch.from_numpy(mat).type(torch.FloatTensor)
    return sp_to_spt(mat)
