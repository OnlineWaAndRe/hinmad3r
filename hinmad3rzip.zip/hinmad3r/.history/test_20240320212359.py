import dgl
import numpy as np
import scipy.sparse as sp

# 创建一个简单的有向图
src = np.array([0, 1, 2])
dst = np.array([1, 2, 0])
g = dgl.graph((src, dst))

# 获取邻接矩阵并转换为 scipy 稀疏矩阵
adj_matrix = sp.csr_matrix(g.adjacency_matrix().toarray())

print(adj_matrix.toarray())
