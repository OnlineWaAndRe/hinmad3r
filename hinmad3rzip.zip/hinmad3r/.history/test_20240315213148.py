import torch
import torch.nn.functional as F
x = torch.randn(5, 5)
print(x)
x_drop = F.dropout(x, 0.5)
print(x_drop)
