import torch
import torch.nn as nn
import torch.nn.functional as F
from layers.gnte import HIN_GATConv
import sys
class hinworld(nn.Module):
    def __init__(self, home_g, in_dims, edge_feats, num_etypes, in_feats, num_type,
                type_feats, num_layers, nclass, heads, feat_drop, attn_drop, alpha, 
                leaky_relu_rate, msg_drop, residual):
        super(hinworld, self).__init__()
        self.g = home_g
        self.num_layers = num_layers
        
        self.gnn = nn.ModuleList()
        self.fc_list = nn.ModuleList([nn.Linear(in_dim, in_feats, bias=True) for in_dim in in_dims])

        activation = F.elu
        #input_projection (no residual)
        self.gnn.append(HIN_GATConv(edge_feats=edge_feats, num_etypes=num_etypes, in_feats=in_feats,
            out_feats=in_feats, num_type=num_type, type_feats=type_feats, num_heads=heads[0],
            feat_drop=feat_drop, attn_drop=attn_drop, leaky_relu_rate=leaky_relu_rate,
            residual=False, activation=activation, alpha=alpha, msg_drop=msg_drop))
        #hidden_projection 
        for layer in range(1, num_layers):
            self.gnn.append(HIN_GATConv(edge_feats=edge_feats, num_etypes=num_etypes, 
            in_feats=in_feats * heads[layer-1],out_feats=in_feats, num_type=num_type, 
            type_feats=type_feats, num_heads=heads[layer],feat_drop=feat_drop, 
            attn_drop=attn_drop, leaky_relu_rate=leaky_relu_rate,
            residual=residual, activation=activation, alpha=alpha, is_dropmsg=True, msg_drop=msg_drop))
        #output_projection
        self.gnn.append(HIN_GATConv(edge_feats=edge_feats, num_etypes=num_etypes, 
            in_feats=in_feats * heads[-2],out_feats=nclass, num_type=num_type, 
            type_feats=type_feats, num_heads=heads[-1],feat_drop=feat_drop, 
            attn_drop=attn_drop, leaky_relu_rate=leaky_relu_rate,
            residual=residual, activation=None, alpha=alpha, msg_drop=msg_drop))
        
        self.epsilon = torch.FloatTensor([1e-12]).cuda()
        self.reset_parameters()
    def reset_parameters(self):
        gain = nn.init.calculate_gain("linear")
        for fc in self.fc_list:
            nn.init.xavier_normal_(fc.weight, gain=gain)
    def forward(self, features_list, e_feat, t_feat, idx):
        h = []
        for fc, feature in zip(self.fc_list, features_list):
            h.append(fc(feature))
        h = torch.cat(h, 0)
        res_attn = None
        for layer in range(self.num_layers):
            h, res_attn = self.gnn[layer](self.g, h, e_feat, t_feat, res_attn = res_attn)
            h = h.flatten(1)
        out, _, = self.gnn[-1](self.g, h, e_feat, t_feat, res_attn = None)
        out = out.mean(1)

        out = out / (torch.max(torch.norm(out, dim=1, keepdim=True), self.epsilon))
        
        return out[idx], h
    
    def get_emd(self, features_list, e_feat, t_feat, idx):
        h = []
        for fc, feature in zip(self.fc_list, features_list):
            h.append(fc(feature))
        h = torch.cat(h, 0)
        res_attn = None
        for layer in range(self.num_layers):
            h, res_attn = self.gnn[layer](self.g, h, e_feat, t_feat, res_attn = res_attn)
            h = h.flatten(1)
        return h[idx]