import torch
import sys
import time
import wandb
import numpy as np
import torch.nn.functional as F
from utils.tools import set_random_seed, get_efeat, plt_show, print_args
from utils.load_dataset import load_dataset
from utils.params import set_params
from utils.pytorchtools import EarlyStopping
from model.model import hinworld
import setproctitle
setproctitle.setproctitle("hinworld")

def computer_sim(x, mask, idx):
    x = F.normalize(x, p = 2, dim = -1)
    x = torch.matmul(x,x.T)
    one = torch.ones_like(x)
    x = one - x

    mt = torch.FloatTensor(mask.toarray())
    d = x.cpu() * mt
    d = d[idx]
    d = torch.sum(d, dim = 1)
    non = torch.count_nonzero(d, dim = 1).float()
    d_tgt = d / non
    
    return torch.sum(ret)


def run(args, fp):
    seeds = args.seeds
    # seeds = torch.arange(0, 1000)
    len_seeds = len(seeds)
    micro_f1s = torch.zeros(len_seeds)
    macro_f1s = torch.zeros(len_seeds)
    len_seeds = 1
    for rep in range(len_seeds):
        set_random_seed(seeds[rep])
        path = sys.path[0] + "/data"
        args.root = path
        start_time = time.time()
        home_g, init_labels, num_classes, node_classes,dl, \
        features_list, train_nid, val_nid, test_nid, adjm = load_dataset(args)
        
        node_cnt = [feat.shape[0] for feat in features_list]
        e_feat = get_efeat(home_g, dl)
        in_dims = [features.shape[1] for features in features_list]
        num_etypes = len(dl.links['count']) * 2 + 1
        heads = [args.num_heads] * args.num_layers + [1]
        node_type = [i for i, z in zip(range(len(node_cnt)), node_cnt) for x in range(z)]
        node_type = torch.tensor(node_type)

        if torch.cuda.is_available():
            device = torch.device("cuda:" + str(args.gpu))
            torch.cuda.set_device(args.gpu)
            home_g = home_g.to(device)
            e_feat = e_feat.to(device)
            init_labels = init_labels.to(device)
            node_type = node_type.to(device)
            features_list = [feat.to(device) for feat in features_list]
        else : device = torch.device("cpu")
        
        net = hinworld(home_g=home_g, in_dims=in_dims, edge_feats=args.e_feats, num_etypes=num_etypes,
            in_feats=args.n_feats, num_type=node_classes, type_feats=args.t_feats, 
            num_layers=args.num_layers, nclass=num_classes, heads=heads, feat_drop=args.feat_drop,
            attn_drop = args.attn_drop, alpha = args.alpha, leaky_relu_rate=args.leaky_relu_rate,
            msg_drop=args.msg_drop, residual=args.residual)
        
        net.to(device)
        optimizer = torch.optim.Adam(net.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min')
        save_path = sys.path[0] + '/outputs/checkpoint/hw_{}.pt'.format(args.dataset)
        early_stopping = EarlyStopping(patience=args.patience, verbose=True, save_path = save_path)
        loss = torch.nn.BCELoss()
        
        plt_lrs = []
        plt_train_loss = []
        plt_val_loss = []
        plt_maf1 = []
        plt_m1f1 = []
        
        for epoch in range(args.epochs):
            plt_lrs.append(optimizer.param_groups[0]['lr'])
            t_start = time.time()
            net.train()
            logits,_ = net(features_list, e_feat, node_type, train_nid)
            logp = logits.sigmoid()
            train_loss = loss(logp, init_labels[train_nid])
            plt_train_loss.append(train_loss.item())
            
            optimizer.zero_grad()
            train_loss.backward()
            optimizer.step()
            t_end = time.time()
            print('Epoch {:05d} | Train_Loss: {:.4f} | Time: {:.4f}'.format(
                    epoch, train_loss.item(), t_end-t_start))
            
            #val
            t_start = time.time()
            net.eval()
            with torch.no_grad():
                logits,_ = net(features_list, e_feat, node_type, val_nid)
                logp = logits.sigmoid()
                val_loss = loss(logp, init_labels[val_nid])
                plt_val_loss.append(val_loss.item())
                pred = (logits.cpu().numpy() > 0).astype(int)
                vret = dl.evaluate_valid(pred, dl.labels_train['data'][val_nid])
                print(vret)
                plt_m1f1.append(vret["micro-f1"])
                plt_maf1.append(vret["macro-f1"])
            # scheduler.step(val_loss)
            t_end = time.time()
            print('Epoch {:05d} | Val_Loss {:.4f} | Time(s) {:.4f}'.format(
                    epoch, val_loss.item(), t_end - t_start))
            # wandb.log({"micro-f1":vret["micro-f1"], "macro-f1": vret["macro-f1"], "val_loss": val_loss})
            early_stopping(val_loss,net)
            if early_stopping.early_stop:
                print('Early stopping!')
                break
        net.load_state_dict(torch.load(save_path))
        net.eval()
        with torch.no_grad():
            logits,emds = net(features_list, e_feat, node_type, test_nid)
            test_logits = logits
            pred = (test_logits.cpu().numpy() > 0).astype(int)
            result = dl.evaluate(pred)
            micro_f1s[rep] = result['micro-f1']
            macro_f1s[rep] = result['macro-f1']
        end_time = time.time()
        print("total compuate times ->", end_time - start_time)
        print("seed = {}".format(seeds[rep]), file=fp)
        print(result, file=fp)
        print(result)

        # plt_show(plt_lrs, type="lrs_ls")
        # plt_show(plt_train_loss, type="train_loss_ls")
        # plt_show(plt_val_loss, type = "val_loss_ls")
        # plt_show(plt_m1f1, type = "m1f1_ls")
        # plt_show(plt_maf1, type="maf1_ls")
    sim = computer_sim(emds,adjm, train_nid)
    print('sim = ', sim)
    print("Macro-f1s = {}, Macro-f1s-std = {}".format(macro_f1s.mean().item(), macro_f1s.std().item()))
    print("Micro-f1s = {}, Micro-f1s-std = {}".format(micro_f1s.mean().item(), micro_f1s.std().item()))
    print("Macro-f1s = {}, Macro-f1s-std = {}".format(macro_f1s.mean().item(), macro_f1s.std().item()), file = fp)
    print("Micro-f1s = {}, Micro-f1s-std = {}".format(micro_f1s.mean().item(), micro_f1s.std().item()), file = fp)
    num_params = sum(p.numel() for p in net.parameters())
    print_args(args, fp)
    print("", file=fp)
    print(num_params / 1e6)
    # wandb.finish()
if __name__ == "__main__":
    args = set_params()
    # wandb.init(
    #     project="hinworld",
    #     config={
    #         "learning_rate":args.lr,
    #         "dataset":args.dataset,
    #     }
    # )
    f_name = args.dataset + "/" + args.dataset + ".txt"
    fp = open(r"./outputs/" + f_name, 'a+')
    fts = np.arange(0, 0.1, 0.001)
    # for ft in fts:
    #     args.alpha = ft
    #     run(args, fp)
    # args.t_feats = 256
    # args.num_layers = 5
    # args.alpha = 0.5
    run(args, fp)
    fp.close()