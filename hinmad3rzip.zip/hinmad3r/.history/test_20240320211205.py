import torch
import torch.nn.functional as F

x = torch.ones(3,5)
x = x / torch.norm(x, dim = -1, keepdim=True)