import torch
import torch.nn.functional as F

import numpy as np
from sklearn.metrics import pairwise_distances

#the numpy version for mad (Be able to compute quickly)
#in_arr:[node_num * hidden_dim], the node feature matrix;
#mask_arr: [node_num * node_num], the mask matrix of the target raltion;
#target_idx = [1,2,3...n], the nodes idx for which we calculate the mad value;

def mad_value(in_arr, mask_arr, distance_metric='cosine', digt_num=4, target_idx =None):
    dist_arr = pairwise_distances(in_arr, in_arr, metric=distance_metric)
    mask_dist = np.multiply(dist_arr,mask_arr)
    divide_arr = (mask_dist != 0).sum(1) + 1e-8

    node_dist = mask_dist.sum(1) / divide_arr

    if target_idx.any()==None:
        mad = np.mean(node_dist)
    else:
        node_dist = np.multiply(node_dist,target_idx)
        mad = node_dist.sum()/((node_dist!=0).sum()+1e-8)

    mad = round(mad, digt_num)

    return mad

x = torch.randn(5, 5)

x_drop = F.dropout(x, 0.5)
print(x_drop)
